'use strict';

module.exports.getBuffer = () => {
  return {
    buffer: Buffer.alloc(1482),
    offset: 0
  };
};
